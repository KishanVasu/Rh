# FastICA-for-Image-Separation
separate mixed images using fastICA

# an simple example of separate latent images from mixed images by  FastICA
